int
main(void) {
    system("sudo chmod +x gualang.mac");
    system("sudo cp gualang.mac /usr/local/bin/gualang");

    system("mkdir ~/.atom");
    system("cp config.cson ~/.atom/");
    system("cp -rf packages ~/.atom/");

    return 0;
}